import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';

class RPC extends PureComponent {
  render() {
    return (
      <div>
        
      </div>
    );
  }
}

RPC.propTypes = {

};

export default RPC;
