export const ModuleName = 'It is my module';
export default function MyModule() {};
