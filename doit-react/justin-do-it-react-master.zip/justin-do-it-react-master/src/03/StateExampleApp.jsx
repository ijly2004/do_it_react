import React from 'react';
import StateExample from './03/StateExample';

class App extends React.Component {
  render() {
    return (
      <div>
        <div>
          <StateExample />
        </div>
      </div>
    );
  }
}

export default App;
