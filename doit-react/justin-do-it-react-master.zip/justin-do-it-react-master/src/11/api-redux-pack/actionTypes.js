export const FETCH_LIST = 'api-redux-pack/FETCH_LIST';
export const FETCH = 'api-redux-pack/FETCH';
export const DELETE = 'api-redux-pack/DELETE';
export const UPDATE = 'api-redux-pack/UPDATE';
export const CREATE = 'api-redux-pack/CREATE';
export const RESET = 'api-redux-pack/RESET';
