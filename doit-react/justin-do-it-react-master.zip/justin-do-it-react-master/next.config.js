module.exports = {
  distDir: "./functions/next"
};
