import '@storybook/addon-actions/register';
// 확장 도구는 이곳에 추가합니다.
import 'storybook-addon-jsx/register';
