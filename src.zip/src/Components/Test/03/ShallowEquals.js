import shallowEquals from 'shallow-equal';

const obj = {name : 'park'};
