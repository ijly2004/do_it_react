import './App.css';
import Test from './Components/Test/Test.js';

function App() {
  return (
    <div>
      <Test />
    </div>
  );
}

export default App;
